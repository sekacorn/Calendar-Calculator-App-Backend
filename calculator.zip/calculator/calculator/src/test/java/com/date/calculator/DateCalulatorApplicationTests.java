package com.date.calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DateCalulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
