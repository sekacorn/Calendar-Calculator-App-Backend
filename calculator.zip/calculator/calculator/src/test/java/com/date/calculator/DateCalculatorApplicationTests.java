package com.date.calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
public class DateCalculatorApplicationTests {

    @Test
    void contextLoads() {
    }
}

