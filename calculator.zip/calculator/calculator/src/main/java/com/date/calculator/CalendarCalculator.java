package com.date.calculator;

import java.time.DayOfWeek;
        import java.time.LocalDate;
        import java.time.temporal.ChronoUnit;
        import java.util.Locale;


public class CalendarCalculator {


    public LocalDate addDates(LocalDate date1, LocalDate date2) {
        return date1.plusDays(date2.getDayOfMonth())
                .plusMonths(date2.getMonthValue())
                .plusYears(date2.getYear());
    }

    public LocalDate subtractDates(LocalDate date1, LocalDate date2) {
        return date1.minusDays(date2.getDayOfMonth())
                .minusMonths(date2.getMonthValue())
                .minusYears(date2.getYear());
    }

    public String getDayOfWeek(LocalDate date) {
        return date.getDayOfWeek().getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH);
    }

    public void printMonth(LocalDate date) {
        LocalDate firstDayOfMonth = date.withDayOfMonth(1);
        DayOfWeek dayOfWeek = firstDayOfMonth.getDayOfWeek();
        int dayOfWeekValue = dayOfWeek.getValue() % 7; // To make Monday = 0

        System.out.println("Mon Tue Wed Thu Fri Sat Sun");

        // Print spaces for days before the first day of the month
        for (int i = 0; i < dayOfWeekValue; i++) {
            System.out.print("    ");
        }

        int monthLength = date.lengthOfMonth();
        for (int i = 1; i <= monthLength; i++) {
            System.out.printf("%3d ", i);
            if ((i + dayOfWeekValue) % 7 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }

    public long countBetween(LocalDate startDate, LocalDate endDate, ChronoUnit unit) {
        return unit.between(startDate, endDate);
    }
}
