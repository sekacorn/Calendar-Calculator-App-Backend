package com.date.calculator;

import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@RestController
@RequestMapping("/app/calendar")
public class CalendarController {

    private final CalendarCalculator calendarCalculator;

    public CalendarController(CalendarCalculator calendarCalculator) {
        this.calendarCalculator = calendarCalculator;
    }

    @PostMapping("/add")
    public LocalDate addDates(@RequestParam("date1") String date1, @RequestParam("date2") String date2) {
        LocalDate parsedDate1 = LocalDate.parse(date1);
        LocalDate parsedDate2 = LocalDate.parse(date2);
        return calendarCalculator.addDates(parsedDate1, parsedDate2);
    }

    @PostMapping("/subtract")
    public LocalDate subtractDates(@RequestParam("date1") String date1, @RequestParam("date2") String date2) {
        LocalDate parsedDate1 = LocalDate.parse(date1);
        LocalDate parsedDate2 = LocalDate.parse(date2);
        return calendarCalculator.subtractDates(parsedDate1, parsedDate2);
    }

    @GetMapping("/dayOfWeek")
    public String getDayOfWeek(@RequestParam("date") String date) {
        LocalDate parsedDate = LocalDate.parse(date);
        return calendarCalculator.getDayOfWeek(parsedDate);
    }

    @GetMapping("/printMonth")
    public void printMonth(@RequestParam("date") String date) {
        LocalDate parsedDate = LocalDate.parse(date);
        calendarCalculator.printMonth(parsedDate);
    }

    @GetMapping("/count")
    public long countBetween(@RequestParam("startDate") String startDate,
                             @RequestParam("endDate") String endDate,
                             @RequestParam("unit") String unit) {
        LocalDate parsedStartDate = LocalDate.parse(startDate);
        LocalDate parsedEndDate = LocalDate.parse(endDate);
        ChronoUnit chronoUnit = ChronoUnit.valueOf(unit.toUpperCase());
        return calendarCalculator.countBetween(parsedStartDate, parsedEndDate, chronoUnit);
    }
}
